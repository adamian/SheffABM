
#include "faceTrackerGpu.h"


faceTrackerGpu::faceTrackerGpu()
{
	poll = 500;
	displayFaces = false;
}

faceTrackerGpu::~faceTrackerGpu()
{
}

bool faceTrackerGpu::updateModule()
{
    inCount = faceTrack.getInputCount();
    outCount = targetPort.getOutputCount();
    if(inCount == 0 || outCount == 0)
    {
	    cout << "Awaiting input and output connections" << endl;
    }
    else
    {
	    ImageOf<PixelRgb> *yarpImage = faceTrack.read();
	    if (yarpImage!=NULL) 
	    {
		    //Alternative way of creating an openCV compatible image
		    //Takes approx twice as much time as uncomented implementation
		    //Also generates IplImage instead of the more useable format Mat
		    //IplImage *cvImage = cvCreateImage(cvSize(yarpImage->width(), yarpImage->height()), IPL_DEPTH_8U, 3);
		    //cvCvtColor((IplImage*)yarpImage->getIplImage(), cvImage, CV_RGB2BGR);
		    count = 0;
		    step = yarpImage->getRowSize() + yarpImage->getPadding();
		    Mat captureFrame_cpuBayer(yarpImage->height(),yarpImage->width(),CV_8UC3,yarpImage->getRawImage(),step);

		    if(format_int == 0)
		    {
			    cv::cvtColor(captureFrame_cpuBayer,captureFrame_cpu,CV_RGB2BGR);
		    }
		    else
		    {
			    cv::cvtColor(captureFrame_cpuBayer,captureFrame_cpuBayer,CV_RGB2GRAY); //1D bayer image
			    cv::cvtColor(captureFrame_cpuBayer,captureFrame_cpu,CV_BayerGB2BGR);	//rgb image out
		    }

		    captureFrame.upload(captureFrame_cpu);
		    cv::gpu::cvtColor(captureFrame,grayscaleFrame,CV_BGR2GRAY);
		    cv::gpu::equalizeHist(grayscaleFrame,grayscaleFrame);
		
		    noFaces = face_cascade.detectMultiScale(grayscaleFrame,objBuf,1.2,5,Size(30,30));
		
		    if(noFaces != 0)
		    {
			    captureFrame_cpu.copyTo(captureFrame_cpuRect);
			    cout << noFaces << endl;
			    std::vector<cv::Mat> faceVec;
			
			    noFaces = 1;

			    Mat vecSizes = cv::Mat::zeros(noFaces,1,CV_16UC1);
			    Mat allFaces(faceSize,1,CV_8UC3,count);

			    objBuf.colRange(0,noFaces).download(vectArr);

			    Rect* facesNew = vectArr.ptr<Rect>();
			    yarp::sig::Vector& posOutput = targetPort.prepare();
			    posOutput.resize(noFaces*3); //each face in the list has a number id, x centre and y centre

			    ImageOf<PixelRgb>& faceImages = imageOut.prepare();

			    for(int i = 0; i<noFaces; i++)
			    {
				    int numel = facesOld.size();
				    if(i < numel)
				    {
					    centrex = facesNew[i].x;
					    centrey = facesNew[i].y;
					
					    centrex_old = facesOld[i].x;
					    centrey_old = facesOld[i].y;

					    d = (centrex_old - centrex) + (centrey_old- centrey);
					    d = abs(d);

					    if(d > 10)
					    {
						    centrex_old = facesOld[i].x;
						    centrey_old = facesOld[i].y;
						    facesOld[i] = facesNew[i];
					    }
				    }		
				    else
				    {
					    centrex_old = facesNew[i].x;
					    centrey_old = facesNew[i].y;
					    centrex = centrex_old;
					    centrey = centrey_old;
					    facesOld.push_back(facesNew[i]);
				    }

				    vecSizes.at<unsigned short>(i) = facesOld[i].width;

				    if(facesOld[i].width > maxSize)
				    {
					    maxSize = facesOld[i].width;
					    biggestFace = i;
				    }
				
				    //required for rectangle faces in full image view
				    Point pt1(facesOld[i].x + facesOld[i].width, facesOld[i].y + facesOld[i].height);
				    Point pt2(facesOld[i].x, facesOld[i].y);
					
				    cv::rectangle(captureFrame_cpuRect,pt1,pt2,cvScalar(0,255,0,0),1,8,0); 
				
				    int base = (i*3);
				    posOutput[base] = i;
				    posOutput[base+1] = centrex;
				    posOutput[base+2] = centrey;


				    if( i == 0 )
				    {
					    Bottle posGazeOutput;
					    posGazeOutput.clear();
					    posGazeOutput.addString("left");
					    posGazeOutput.addDouble(centrex);
					    posGazeOutput.addDouble(centrey);
					    posGazeOutput.addDouble(1.0);

					    gazePort.write(posGazeOutput);
				    }

			    }
			    Mat indices;
			    cv::sortIdx(vecSizes, indices, cv::SORT_EVERY_COLUMN | cv::SORT_DESCENDING);
			
			    for(int i = 0; i<noFaces; i++)
			    {
				    if(facesOld[i].area() != 0)
				    {
					    Mat temp = captureFrame_cpu.operator()(facesOld[i]).clone();
					    cv::resize(temp,temp,Size(faceSize,faceSize));
					    faceVec.push_back(temp);
				    }
			    }
			    hconcat(faceVec,allFaces);
			    //faceVec.~vector();

			    if( displayFaces )
			    {
				    cv::imshow("faces",allFaces);
			    }


			    CVtoYarp(allFaces,faceImages);

			    imageOut.write();
		    }

		    targetPort.write();
		    waitKey(1);
	    }
    }

    if( displayFaces )
	    cv::imshow("wholeImage",captureFrame_cpuRect);

    return true;
}

bool faceTrackerGpu::configure(ResourceFinder &rf)
{
    Property config;
    config.fromConfigFile(rf.findFile("from").c_str());

    Bottle &bGeneral = config.findGroup("general");

    imageInPort = bGeneral.find("imageInPort").asString().c_str();
    vectorOutPort = bGeneral.find("vectorOutPort").asString().c_str();
    imageOutPort = bGeneral.find("imageOutPort").asString().c_str();
    gazeOutPort = bGeneral.find("gazeOutPort").asString().c_str();
    syncPortConf = bGeneral.find("syncInPort").asString().c_str();
    cascadeFile = bGeneral.find("cascadeFile").asString().c_str();

    cout << "------------------------" << endl;
    cout << imageInPort.c_str() << endl;
    cout << vectorOutPort << endl;
    cout << imageOutPort << endl;
    cout << gazeOutPort << endl;
    cout << syncPortConf << endl;
    cout << cascadeFile << endl;
    cout << "------------------------" << endl;

    isGPUavailable = getCudaEnabledDeviceCount();

	if (isGPUavailable == 0)
	{
		cout << "No GPU found or the library is compiled without GPU support" << endl;
		cout << "Proceeding on CPU" << endl;
		cout << "Detecting largest face in view only for performance" << endl;
		hardware_int = 0;

        return false;
	}
	else
	{
		hardware_int = 1;
		cv::gpu::getDevice();
		cout << "Proceeding on GPU" << endl;
	}

	inOpen = faceTrack.open(imageInPort.c_str());
	outOpen = targetPort.open(vectorOutPort.c_str());
	imageOutOpen = imageOut.open(imageOutPort.c_str());

	gazeOut = gazePort.open(gazeOutPort.c_str());
	syncPortIn = syncPort.open(syncPortConf.c_str());

	syncBottleOut.clear();
	syncBottleOut.addString("stat");

	if(!inOpen | !outOpen | !imageOutOpen | !gazeOut )
	{
		cout << "Could not open ports. Exiting" << endl;
		return false;
	}

	inCount = faceTrack.getInputCount();
	outCount = faceTrack.getOutputCount();

	step = 0;
    maxSize = 0;
    biggestFace = 0;
    count = 0;
    faceSize = 200;
	inStatus = true;

	if( displayFaces )
	{
		namedWindow("faces",1);
		namedWindow("wholeImage",1);
		waitKey(1);
	}		
	
	face_cascade.load(cascadeFile.c_str());
}

bool faceTrackerGpu::interruptModule()
{
    return true;
}

double faceTrackerGpu::getPeriod()
{
    return 0.1;
}

void faceTrackerGpu::CVtoYarp(Mat MatImage, ImageOf<PixelRgb> & yarpImage)
{
	IplImage* IPLfromMat = new IplImage(MatImage);

	yarpImage.resize(IPLfromMat->width,IPLfromMat->height);

	IplImage * iplYarpImage = (IplImage*)yarpImage.getIplImage();

	if (IPL_ORIGIN_TL == IPLfromMat->origin){
			cvCopy(IPLfromMat, iplYarpImage, 0);
	}
	else{
			cvFlip(IPLfromMat, iplYarpImage, 0);
	}

	if (IPLfromMat->channelSeq[0]=='B') {
			cvCvtColor(iplYarpImage, iplYarpImage, CV_BGR2RGB);
	}
}

